import PyPDF2
import requests
from io import BytesIO
import logging

logger = logging.getLogger(__name__)

class PDFService:
    async def extract_text(self, file_url: str) -> dict:
        """
        Extract text from PDF file
        
        Args:
            file_url: URL of the PDF file
        
        Returns:
            Dictionary with extracted text and metadata
        """
        try:
            # Download PDF from URL
            response = requests.get(file_url)
            pdf_file = BytesIO(response.content)
            
            # Extract text from PDF
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            text_content = ""
            page_count = len(pdf_reader.pages)
            
            for page_num, page in enumerate(pdf_reader.pages):
                text_content += f"\n--- صفحة {page_num + 1} ---\n"
                text_content += page.extract_text()
            
            logger.info(f"PDF extracted successfully: {page_count} pages")
            
            return {
                "text": text_content,
                "page_count": page_count,
                "file_size": len(response.content)
            }
        except Exception as e:
            logger.error(f"Error extracting text from PDF: {str(e)}")
            raise Exception(f"Failed to extract text from PDF: {str(e)}")

# Create singleton instance
pdf_service = PDFService()
