import openai
from config import settings
import logging
import requests
from io import BytesIO

logger = logging.getLogger(__name__)

class AudioService:
    def __init__(self):
        openai.api_key = settings.openai_api_key
    
    async def transcribe_audio(self, file_url: str, language: str = "ar") -> dict:
        """
        Transcribe audio file using OpenAI Whisper API
        
        Args:
            file_url: URL of the audio file
            language: Language code (default: "ar" for Arabic)
        
        Returns:
            Dictionary with transcription text and metadata
        """
        try:
            # Download file from URL
            response = requests.get(file_url)
            audio_file = BytesIO(response.content)
            
            # Get filename from URL
            file_name = file_url.split('/')[-1]
            
            # Transcribe using Whisper API
            transcript = openai.Audio.transcribe(
                model="whisper-1",
                file=audio_file,
                language=language
            )
            
            logger.info(f"Audio transcribed successfully: {file_name}")
            
            return {
                "text": transcript.get("text", ""),
                "language": transcript.get("language", language),
                "duration": transcript.get("duration"),
                "segments": transcript.get("segments", [])
            }
        except Exception as e:
            logger.error(f"Error transcribing audio: {str(e)}")
            raise Exception(f"Failed to transcribe audio: {str(e)}")

# Create singleton instance
audio_service = AudioService()
