import openai
from config import settings
import logging
import json
import re

logger = logging.getLogger(__name__)

class AIService:
    def __init__(self):
        openai.api_key = settings.openai_api_key
        self.model = settings.openai_model
        self.chunk_size = 3000  # Characters per chunk
    
    def _split_text_into_chunks(self, text: str) -> list:
        """Split text into manageable chunks"""
        chunks = []
        current_chunk = ""
        
        # Split by sentences
        sentences = re.split(r'(?<=[.!?])\s+', text)
        
        for sentence in sentences:
            if len(current_chunk) + len(sentence) < self.chunk_size:
                current_chunk += " " + sentence
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = sentence
        
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks if chunks else [text]
    
    async def analyze_text(self, text: str) -> dict:
        """
        Analyze text and generate summary, key points, and quiz questions
        
        Args:
            text: The text to analyze
        
        Returns:
            Dictionary with summary, key points, and quiz questions
        """
        try:
            # Split text into chunks if too long
            chunks = self._split_text_into_chunks(text)
            logger.info(f"Text split into {len(chunks)} chunks")
            
            # Combine results from all chunks
            all_summaries = []
            all_key_points = []
            all_quizzes = []
            
            for i, chunk in enumerate(chunks):
                logger.info(f"Processing chunk {i+1}/{len(chunks)}")
                
                # Generate summary and analysis for this chunk
                response = openai.ChatCompletion.create(
                    model=self.model,
                    messages=[
                        {
                            "role": "system",
                            "content": "أنت مساعد تعليمي ذكي متخصص في تحليل النصوص وإنشاء مواد تعليمية. يجب أن تجيب بالعربية فقط."
                        },
                        {
                            "role": "user",
                            "content": f"""حلل النص التالي وقدم:
1. ملخص قصير (2-3 فقرات)
2. قائمة بـ 5-7 نقاط رئيسية
3. 3 أسئلة اختبار متعددة الخيارات (4 خيارات لكل سؤال)

الرجاء تنسيق الإجابة كـ JSON بالصيغة التالية:
{{
    "summary": "الملخص هنا",
    "key_points": ["نقطة 1", "نقطة 2", ...],
    "quizzes": [
        {{
            "question": "السؤال هنا",
            "options": ["الخيار 1", "الخيار 2", "الخيار 3", "الخيار 4"],
            "correct_answer": 0
        }},
        ...
    ]
}}

النص:
{chunk}"""
                        }
                    ],
                    temperature=0.7,
                    max_tokens=2000
                )
                
                # Parse response
                response_text = response.choices[0].message.content
                
                # Extract JSON from response
                json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
                if json_match:
                    try:
                        chunk_result = json.loads(json_match.group())
                        all_summaries.append(chunk_result.get("summary", ""))
                        all_key_points.extend(chunk_result.get("key_points", []))
                        all_quizzes.extend(chunk_result.get("quizzes", []))
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse JSON from chunk {i+1}")
                        all_summaries.append(response_text[:500])
            
            # Combine and refine results
            combined_summary = " ".join(all_summaries)
            
            # Remove duplicates from key points
            unique_key_points = list(dict.fromkeys(all_key_points))[:10]
            
            # Keep unique quizzes (limit to 10)
            unique_quizzes = all_quizzes[:10]
            
            logger.info("Text analysis completed successfully")
            
            return {
                "summary": combined_summary,
                "key_points": unique_key_points,
                "quizzes": unique_quizzes
            }
        except Exception as e:
            logger.error(f"Error analyzing text: {str(e)}")
            raise Exception(f"Failed to analyze text: {str(e)}")

# Create singleton instance
ai_service = AIService()
