import os
from typing import List

class Settings:
    # OpenAI Configuration
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = "gpt-4o"
    
    # Wasabi S3 Configuration
    wasabi_access_key: str = os.getenv("WASABI_ACCESS_KEY", "")
    wasabi_secret_key: str = os.getenv("WASABI_SECRET_KEY", "")
    wasabi_bucket_name: str = os.getenv("WASABI_BUCKET_NAME", "")
    wasabi_region: str = os.getenv("WASABI_REGION", "us-east-1")
    wasabi_endpoint_url: str = os.getenv("WASABI_ENDPOINT_URL", "https://s3.wasabisys.com")
    
    # Database Configuration
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./smart_learning.db")
    
    # Server Configuration
    debug: bool = os.getenv("DEBUG", "False").lower() == "true"
    allowed_origins: List[str] = ["http://localhost:5173", "http://localhost:3000"]
    
    # File Upload Configuration
    max_file_size: int = 50 * 1024 * 1024  # 50MB
    allowed_pdf_extensions: List[str] = [".pdf"]
    allowed_audio_extensions: List[str] = [".mp3", ".wav", ".m4a", ".ogg"]
    
    # Authentication Configuration
    secret_key: str = os.getenv("SECRET_KEY", "your-secret-key-change-in-production")
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7
    
    # Admin Configuration
    admin_email: str = os.getenv("ADMIN_EMAIL", "admin@smartlearning.com")
    admin_username: str = os.getenv("ADMIN_USERNAME", "admin")
    admin_password: str = os.getenv("ADMIN_PASSWORD", "admin123")
    
settings = Settings()
