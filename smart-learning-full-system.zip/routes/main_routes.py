from flask import Blueprint, request, jsonify
import logging
from config import settings
from database import SessionLocal
from models import FileRecord, AnalysisResult, FileTypeEnum
from services import storage_service, audio_service, pdf_service, ai_service
from schemas import (
    FileUploadResponse, AudioProcessRequest, AudioProcessResponse,
    PDFProcessRequest, PDFProcessResponse, AnalyzeRequest, AnalyzeResponse
)
from pydantic import ValidationError

logger = logging.getLogger(__name__)
main_bp = Blueprint('main', __name__)

@main_bp.route('/upload', methods=['POST'])
def upload_file():
    """Upload a file (PDF or Audio)"""
    db = SessionLocal()
    try:
        if 'file' not in request.files:
            return jsonify({"detail": "No file part"}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({"detail": "No selected file"}), 400
            
        # Validate file type
        file_extension = "." + file.filename.split(".")[-1].lower()
        
        if file_extension in settings.allowed_pdf_extensions:
            file_type = FileTypeEnum.PDF
        elif file_extension in settings.allowed_audio_extensions:
            file_type = FileTypeEnum.AUDIO
        else:
            return jsonify({"detail": f"File type not supported. Allowed: {settings.allowed_pdf_extensions + settings.allowed_audio_extensions}"}), 400
        
        # Read file content
        file_content = file.read()
        
        # Check file size
        if len(file_content) > settings.max_file_size:
            return jsonify({"detail": f"File size exceeds maximum allowed size of {settings.max_file_size / 1024 / 1024}MB"}), 413
        
        # Upload to storage (Note: services are currently async in original project, 
        # but Flask is sync. We'll use a helper to run them or adapt if needed.
        # Since we are in a sync Flask route, we'll need to handle the async calls.)
        import asyncio
        upload_result = asyncio.run(storage_service.upload_file(
            file_content,
            file.filename,
            file_type.value
        ))
        
        # Save file record to database
        file_record = FileRecord(
            file_id=upload_result["file_id"],
            file_name=file.filename,
            file_type=file_type,
            file_url=upload_result["file_url"],
            file_size=len(file_content)
        )
        db.add(file_record)
        db.commit()
        db.refresh(file_record)
        
        logger.info(f"File uploaded successfully: {file.filename}")
        
        return jsonify(upload_result)
    
    except Exception as e:
        logger.error(f"Error uploading file: {str(e)}")
        return jsonify({"detail": str(e)}), 500
    finally:
        db.close()

@main_bp.route('/process-audio', methods=['POST'])
def process_audio():
    """Process audio file and transcribe to text"""
    try:
        data = request.get_json()
        req_obj = AudioProcessRequest(**data)
        
        import asyncio
        result = asyncio.run(audio_service.transcribe_audio(
            req_obj.file_url,
            req_obj.language
        ))
        return jsonify(result)
    except ValidationError as e:
        return jsonify({"detail": e.errors()}), 400
    except Exception as e:
        logger.error(f"Error processing audio: {str(e)}")
        return jsonify({"detail": str(e)}), 500

@main_bp.route('/process-pdf', methods=['POST'])
def process_pdf():
    """Process PDF file and extract text"""
    try:
        data = request.get_json()
        req_obj = PDFProcessRequest(**data)
        
        import asyncio
        result = asyncio.run(pdf_service.extract_text(req_obj.file_url))
        return jsonify(result)
    except ValidationError as e:
        return jsonify({"detail": e.errors()}), 400
    except Exception as e:
        logger.error(f"Error processing PDF: {str(e)}")
        return jsonify({"detail": str(e)}), 500

@main_bp.route('/analyze', methods=['POST'])
def analyze_text():
    """Analyze text and generate summary, key points, and quiz questions"""
    db = SessionLocal()
    try:
        data = request.get_json()
        req_obj = AnalyzeRequest(**data)
        
        import asyncio
        # Analyze text using AI
        analysis_result = asyncio.run(ai_service.analyze_text(req_obj.text))
        
        # Save analysis result to database
        db_result = AnalysisResult(
            file_id=req_obj.file_id,
            file_name=req_obj.file_name,
            file_type=FileTypeEnum(req_obj.file_type),
            original_text=req_obj.text[:5000],  # Store first 5000 chars
            summary=analysis_result["summary"],
            key_points=analysis_result["key_points"],
            quizzes=analysis_result["quizzes"]
        )
        db.add(db_result)
        db.commit()
        db.refresh(db_result)
        
        logger.info(f"Text analyzed successfully: {req_obj.file_name}")
        
        return jsonify(analysis_result)
    except ValidationError as e:
        return jsonify({"detail": e.errors()}), 400
    except Exception as e:
        logger.error(f"Error analyzing text: {str(e)}")
        return jsonify({"detail": str(e)}), 500
    finally:
        db.close()

@main_bp.route('/results/<file_id>', methods=['GET'])
def get_results(file_id):
    """Get analysis results for a specific file"""
    db = SessionLocal()
    try:
        result = db.query(AnalysisResult).filter(
            AnalysisResult.file_id == file_id
        ).first()
        
        if not result:
            return jsonify({"detail": "Analysis result not found"}), 404
        
        # Convert SQLAlchemy object to dict for JSON response
        return jsonify({
            "file_id": result.file_id,
            "file_name": result.file_name,
            "file_type": result.file_type.value,
            "summary": result.summary,
            "key_points": result.key_points,
            "quizzes": result.quizzes,
            "created_at": result.created_at.isoformat() if result.created_at else None
        })
    except Exception as e:
        logger.error(f"Error retrieving results: {str(e)}")
        return jsonify({"detail": str(e)}), 500
    finally:
        db.close()

from routes.auth import token_required

@main_bp.route('/history', methods=['GET'])
@token_required
def get_history(current_user):
    """Get analysis results for the current user"""
    db = SessionLocal()
    try:
        # Filter by user_id if your model supports it, otherwise return all for now
        # Assuming AnalysisResult might need a user_id field for full multi-user support
        results = db.query(AnalysisResult).order_by(
            AnalysisResult.created_at.desc()
        ).limit(50).all()
        
        history = []
        for r in results:
            history.append({
                "file_id": r.file_id,
                "file_name": r.file_name,
                "file_type": r.file_type.value,
                "summary": r.summary,
                "key_points": r.key_points,
                "quizzes": r.quizzes,
                "created_at": r.created_at.isoformat() if r.created_at else None
            })
        
        return jsonify(history)
    except Exception as e:
        logger.error(f"Error retrieving history: {str(e)}")
        return jsonify({"detail": str(e)}), 500
    finally:
        db.close()
