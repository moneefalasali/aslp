// الحالة العامة للتطبيق
let state = {
    currentPage: 'home',
    file: null,
    isProcessing: false,
    progress: 0,
    analysisResult: null,
    history: [],
    selectedAnswers: {},
    user: JSON.parse(localStorage.getItem('user') || 'null'),
    token: localStorage.getItem('access_token')
};

// تهيئة الأيقونات والتحقق من المستخدم
function init() {
    lucide.createIcons();
    updateAuthUI();
    if (state.token) {
        loadHistoryFromServer();
    }
}

function updateAuthUI() {
    const authBtns = document.getElementById('auth-buttons');
    const userProf = document.getElementById('user-profile');
    const userName = document.getElementById('user-name');

    if (state.user && state.token) {
        authBtns.classList.add('hidden');
        userProf.classList.remove('hidden');
        userName.textContent = state.user.full_name || state.user.username;
    } else {
        authBtns.classList.remove('hidden');
        userProf.classList.add('hidden');
    }
}

function logout() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('user');
    window.location.reload();
}

async function loadHistoryFromServer() {
    try {
        const res = await fetch('/api/history', {
            headers: { 'Authorization': `Bearer ${state.token}` }
        });
        if (res.ok) {
            state.history = await res.json();
            if (state.currentPage === 'history') renderHistory();
        }
    } catch (err) {
        console.error('فشل تحميل السجل من الخادم');
    }
}

init();

// التنقل بين الصفحات
function navigate(page) {
    state.currentPage = page;
    
    // إخفاء جميع الصفحات
    document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
    
    // إظهار الصفحة المطلوبة
    const targetPage = document.getElementById(`page-${page}`);
    if (targetPage) {
        targetPage.classList.remove('hidden');
    }

    // تحديث البيانات إذا لزم الأمر
    if (page === 'history') {
        renderHistory();
    }
    
    window.scrollTo(0, 0);
}

// التعامل مع رفع الملفات
const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-input');
const uploadBtn = document.getElementById('upload-btn');

if (dropZone) {
    dropZone.onclick = () => fileInput.click();

    dropZone.ondragover = (e) => {
        e.preventDefault();
        dropZone.classList.add('dragging');
    };

    dropZone.ondragleave = () => {
        dropZone.classList.remove('dragging');
    };

    dropZone.ondrop = (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragging');
        if (e.dataTransfer.files.length > 0) {
            handleFileSelect(e.dataTransfer.files[0]);
        }
    };
}

if (fileInput) {
    fileInput.onchange = (e) => {
        if (e.target.files.length > 0) {
            handleFileSelect(e.target.files[0]);
        }
    };
}

function handleFileSelect(file) {
    const acceptedFormats = ['.pdf', '.mp3', '.wav', '.m4a', '.ogg'];
    const ext = '.' + file.name.split('.').pop().toLowerCase();

    if (!acceptedFormats.includes(ext)) {
        showError(`صيغة الملف غير مدعومة. الصيغ المدعومة: ${acceptedFormats.join(', ')}`);
        return;
    }

    if (file.size > 50 * 1024 * 1024) {
        showError('حجم الملف يتجاوز 50 ميجابايت');
        return;
    }

    state.file = file;
    hideError();
    
    // تحديث واجهة معلومات الملف
    document.getElementById('file-info').classList.remove('hidden');
    document.getElementById('file-name').textContent = file.name;
    document.getElementById('file-size').textContent = (file.size / (1024 * 1024)).toFixed(2) + ' ميجابايت';
    
    const iconType = file.type.startsWith('audio/') ? 'music' : 'file-text';
    document.getElementById('file-icon').setAttribute('data-lucide', iconType);
    lucide.createIcons();

    uploadBtn.disabled = false;
}

function showError(msg) {
    const alert = document.getElementById('error-alert');
    document.getElementById('error-message').textContent = msg;
    alert.classList.remove('hidden');
}

function hideError() {
    document.getElementById('error-alert').classList.add('hidden');
}

// التعامل مع عملية الرفع والمعالجة الحقيقية عبر Flask API
async function handleUpload() {
    if (!state.file) return;

    state.isProcessing = true;
    uploadBtn.disabled = true;
    document.getElementById('progress-section').classList.remove('hidden');
    hideError();

    try {
        const formData = new FormData();
        formData.append('file', state.file);

        // 1. رفع الملف
        updateProgress(10);
        const headers = state.token ? { 'Authorization': `Bearer ${state.token}` } : {};
        const uploadRes = await fetch('/api/upload', {
            method: 'POST',
            headers: headers,
            body: formData
        });
        
        if (!uploadRes.ok) {
            const errData = await uploadRes.json();
            throw new Error(errData.detail || 'فشل رفع الملف');
        }
        
        const { file_url, file_id } = await uploadRes.json();
        updateProgress(40);

        // 2. معالجة الملف (PDF أو صوت)
        const fileType = state.file.type.startsWith('audio/') ? 'audio' : 'pdf';
        const processEndpoint = fileType === 'audio' ? '/api/process-audio' : '/api/process-pdf';
        
        const processRes = await fetch(processEndpoint, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                ...(state.token ? { 'Authorization': `Bearer ${state.token}` } : {})
            },
            body: JSON.stringify({ file_url: file_url, file_id: file_id })
        });

        if (!processRes.ok) throw new Error('فشل استخراج النصوص من الملف');
        const { text } = await processRes.json();
        updateProgress(70);

        // 3. التحليل بالذكاء الاصطناعي
        const analyzeRes = await fetch('/api/analyze', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                ...(state.token ? { 'Authorization': `Bearer ${state.token}` } : {})
            },
            body: JSON.stringify({
                text: text,
                file_id: file_id,
                file_name: state.file.name,
                file_type: fileType
            })
        });

        if (!analyzeRes.ok) throw new Error('فشل تحليل النص بالذكاء الاصطناعي');
        const analysisData = await analyzeRes.json();
        
        updateProgress(100);

        const finalResult = {
            id: file_id,
            fileName: state.file.name,
            fileType: fileType,
            summary: analysisData.summary,
            keyPoints: analysisData.key_points,
            quizzes: analysisData.quizzes,
            createdAt: new Date().toISOString()
        };

        state.analysisResult = finalResult;
        state.history.unshift(finalResult);
        localStorage.setItem('smart_learning_history', JSON.stringify(state.history));

        document.getElementById('success-alert').classList.remove('hidden');
        setTimeout(() => {
            displayResults(finalResult);
            navigate('results');
            resetUploadState();
        }, 1000);

    } catch (err) {
        showError(err.message || 'حدث خطأ أثناء معالجة الملف');
        state.isProcessing = false;
        uploadBtn.disabled = false;
    }
}

function updateProgress(val) {
    state.progress = val;
    document.getElementById('progress-text').textContent = val + '%';
    document.getElementById('progress-fill').style.width = val + '%';
}

function resetUploadState() {
    state.file = null;
    state.isProcessing = false;
    state.progress = 0;
    document.getElementById('file-info').classList.add('hidden');
    document.getElementById('progress-section').classList.add('hidden');
    document.getElementById('success-alert').classList.add('hidden');
    uploadBtn.disabled = true;
    fileInput.value = '';
}

// عرض النتائج
function displayResults(result) {
    document.getElementById('res-file-name').textContent = result.fileName;
    const date = new Date(result.createdAt).toLocaleDateString('ar-SA');
    const type = result.fileType === 'pdf' ? 'ملف PDF' : 'ملف صوتي';
    document.getElementById('res-file-meta').textContent = `${type} • ${date}`;
    document.getElementById('res-summary').textContent = result.summary;

    const pointsList = document.getElementById('res-key-points');
    pointsList.innerHTML = '';
    result.keyPoints.forEach((point, i) => {
        const li = document.createElement('li');
        li.style.display = 'flex';
        li.style.gap = '0.75rem';
        li.style.marginBottom = '0.75rem';
        li.innerHTML = `<span style="color: #2563eb; font-weight: bold;">${i + 1}.</span> <span>${point}</span>`;
        pointsList.appendChild(li);
    });

    const quizContainer = document.getElementById('res-quizzes');
    quizContainer.innerHTML = '';
    state.selectedAnswers = {};
    
    result.quizzes.forEach((quiz, qIdx) => {
        const div = document.createElement('div');
        div.className = 'quiz-item';
        div.innerHTML = `<h4 style="font-weight: 600; margin-bottom: 1rem;">السؤال ${qIdx + 1}: ${quiz.question}</h4>`;
        
        const optionsDiv = document.createElement('div');
        quiz.options.forEach((opt, oIdx) => {
            const label = document.createElement('label');
            label.className = 'quiz-option';
            label.id = `q${qIdx}-o${oIdx}`;
            label.innerHTML = `
                <input type="radio" name="quiz-${qIdx}" onchange="selectAnswer(${qIdx}, ${oIdx})">
                <span>${opt}</span>
            `;
            optionsDiv.appendChild(label);
        });
        
        div.appendChild(optionsDiv);
        quizContainer.appendChild(div);
    });

    // إعادة تعيين أزرار الاختبار
    document.getElementById('show-results-btn').classList.remove('hidden');
    document.getElementById('score-display').classList.add('hidden');
}

function selectAnswer(qIdx, oIdx) {
    state.selectedAnswers[qIdx] = oIdx;
}

function showQuizResults() {
    const result = state.analysisResult;
    let correctCount = 0;

    result.quizzes.forEach((quiz, qIdx) => {
        const selected = state.selectedAnswers[qIdx];
        const correct = quiz.correctAnswer;

        quiz.options.forEach((_, oIdx) => {
            const el = document.getElementById(`q${qIdx}-o${oIdx}`);
            el.classList.remove('selected', 'correct', 'incorrect');
            
            if (oIdx === correct) {
                el.classList.add('correct');
                const check = document.createElement('span');
                check.style.color = '#16a34a';
                check.style.fontWeight = 'bold';
                check.textContent = ' ✓';
                el.appendChild(check);
            } else if (oIdx === selected) {
                el.classList.add('incorrect');
                const cross = document.createElement('span');
                cross.style.color = '#dc2626';
                cross.style.fontWeight = 'bold';
                cross.textContent = ' ✗';
                el.appendChild(cross);
            }
            
            el.querySelector('input').disabled = true;
        });

        if (selected === correct) correctCount++;
    });

    const score = Math.round((correctCount / result.quizzes.length) * 100);
    document.getElementById('score-value').textContent = score + '%';
    document.getElementById('score-display').classList.remove('hidden');
    document.getElementById('show-results-btn').classList.add('hidden');
}

function resetQuiz() {
    displayResults(state.analysisResult);
}

// عرض السجل
function renderHistory() {
    const list = document.getElementById('history-list');
    const empty = document.getElementById('history-empty');
    
    if (state.history.length === 0) {
        list.classList.add('hidden');
        empty.classList.remove('hidden');
        return;
    }

    list.classList.remove('hidden');
    empty.classList.add('hidden');
    list.innerHTML = '';

    state.history.forEach(item => {
        const card = document.createElement('div');
        card.className = 'card';
        card.style.cursor = 'pointer';
        card.onclick = () => {
            state.analysisResult = item;
            displayResults(item);
            navigate('results');
        };

        const date = new Date(item.createdAt).toLocaleDateString('ar-SA');
        const icon = item.fileType === 'pdf' ? 'file-text' : 'headphones';

        card.innerHTML = `
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                <i data-lucide="${icon}" style="color: #2563eb;"></i>
                <div style="flex: 1;">
                    <h4 style="font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${item.fileName}</h4>
                    <p style="font-size: 0.875rem; color: #6b7280;">${date}</p>
                </div>
            </div>
            <p style="font-size: 0.875rem; color: #4b5563; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                ${item.summary}
            </p>
        `;
        list.appendChild(card);
    });
    lucide.createIcons();
}

// وظائف إضافية
function downloadReport() {
    const result = state.analysisResult;
    const content = `
منصة التعلم الذكي - تقرير التحليل
=====================================

الملف: ${result.fileName}
النوع: ${result.fileType === 'pdf' ? 'ملف PDF' : 'ملف صوتي'}
التاريخ: ${new Date(result.createdAt).toLocaleDateString('ar-SA')}

الملخص:
-------
${result.summary}

النقاط الرئيسية:
----------------
${result.keyPoints.map((point, i) => `${i + 1}. ${point}`).join('\n')}

أسئلة الاختبار:
---------------
${result.quizzes.map((quiz, i) => `
السؤال ${i + 1}: ${quiz.question}
الخيارات:
${quiz.options.map((opt, j) => `  ${String.fromCharCode(97 + j)}) ${opt}`).join('\n')}
الإجابة الصحيحة: ${quiz.options[quiz.correctAnswer]}
`).join('\n')}
    `;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `تقرير-${result.fileName}.txt`;
    a.click();
    URL.revokeObjectURL(url);
}

function shareResult() {
    const text = `تحليل ذكي للملف: ${state.analysisResult.fileName}\n\nمن منصة التعلم الذكي`;
    if (navigator.share) {
        navigator.share({ title: 'منصة التعلم الذكي', text: text });
    } else {
        alert('تم نسخ رابط المشاركة (محاكاة)');
    }
}
